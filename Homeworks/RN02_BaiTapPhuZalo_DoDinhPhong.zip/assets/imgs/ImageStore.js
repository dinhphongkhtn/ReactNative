import blackwidow from "./blackwidow.jpeg";
import captain from "./captain.jpg";
import flash from "./flash.jpg";
import ironman from "./ironman.jpeg";
import spiderman from "./spiderman.jpeg";
import strange from "./strange.jpg";
import suppergirl from "./suppergirl.jpg";
import wanda from "./wanda.jpg";
import wonderwoman from "./wonderwoman.jpg";
import yasuo from "./yasuo.jpg";

export {blackwidow,captain,flash,ironman,spiderman,strange,suppergirl,wanda,wonderwoman,yasuo}