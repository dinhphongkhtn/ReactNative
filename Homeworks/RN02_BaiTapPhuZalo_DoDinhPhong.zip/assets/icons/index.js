import Entypo from "react-native-vector-icons/AntDesign";

export default Entypo;