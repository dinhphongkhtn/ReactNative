import {  
    blackwidow,
    captain,
    flash,
    ironman,
    spiderman,
    strange,
    suppergirl,
    wanda,
    wonderwoman,
    yasuo}
 from "../assets/imgs/ImageStore";

const heroData = [
    {
        Id:1,
        Name:'BlackWindow',
        Avarta: blackwidow,
    },
    {
        Id:2,
        Name:'Captain',
        Avarta: captain,
    },
    {
        Id:3,
        Name:'Flash',
        Avarta: flash,
    },
    {
        Id:4,
        Name:'Iron man',
        Avarta: ironman,
    },
    {
        Id:5,
        Name:'Spider man',
        Avarta: spiderman,
    },
    {
        Id:6,
        Name:'Strange',
        Avarta: strange,
    },
    {
        Id:7,
        Name:'Supper girl',
        Avarta: suppergirl,
    },
    {
        Id:8,
        Name:'Wanda',
        Avarta: wanda,
    },
    {
        Id:9,
        Name:'Wonder woman',
        Avarta: wonderwoman,
    },
    {
        Id:10,
        Name:'Yasuo',
        Avarta: yasuo,
    },
]

export default heroData;