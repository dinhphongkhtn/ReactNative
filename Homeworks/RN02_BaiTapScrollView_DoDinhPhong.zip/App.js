import React, { Component } from 'react';
import BaiTapScrollView from './src/components/BaiTapScrollView';

const App = () => {

  return (
    <BaiTapScrollView/>
  );
};

export default App;