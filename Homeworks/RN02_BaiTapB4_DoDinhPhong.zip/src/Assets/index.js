import defaultIcon from "./images/angry.png";

export default defaultIcon;